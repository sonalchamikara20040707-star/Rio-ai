import os
import re
import ast
import operator
import tempfile
from pathlib import Path
from datetime import datetime
from urllib.parse import quote_plus

import streamlit as st
import streamlit.components.v1 as components
from google import genai
from google.genai import types
from gtts import gTTS
from streamlit_mic_recorder import speech_to_text

st.set_page_config(page_title="Rio AI Assistant", page_icon="🤖", layout="centered")
BASE_DIR = Path(__file__).parent
wake_component = components.declare_component("rio_wake_listener", path=str(BASE_DIR / "wake_component"))

st.markdown("""
<style>
.main {max-width: 950px;}
.hero {padding:1.3rem;border-radius:18px;text-align:center;background:linear-gradient(120deg,#172554,#4338ca);color:white;}
.credit {text-align:center;color:gray;font-size:.9rem;margin-top:2rem;}
.small-note {font-size:.9rem;color: #777;}
</style>
<div class="hero"><h1>🤖 Rio AI</h1><p>ඔබේ හඬින් ක්‍රියාකරන AI සහායකයා • Your Voice Assistant</p></div>
""", unsafe_allow_html=True)
st.caption("'Hey Rio' කියා අමතා ප්‍රශ්න අසන්න. වෙබ් සෙවීම් සහ මූලික පරිගණක කාර්යයන් හඬින් ඉල්ලන්න.")

api_key = st.sidebar.text_input("Google Gemini API Key", type="password", value=os.getenv("GEMINI_API_KEY", ""), help="API Key එක රහසිගතව තබාගන්න.")
model = st.sidebar.selectbox("AI Model", ["gemini-2.5-flash", "gemini-2.0-flash"], index=0)
voice_on = st.sidebar.toggle("පිළිතුරු හඬින් කියවන්න", value=True)
wake_language = st.sidebar.selectbox("අවදි වචනය", ["English (Hey Rio)", "සිංහල (රියෝ)"], index=0)

for key, default in [("messages", []), ("wake_enabled", False), ("last_wake_event", None), ("pending_voice_text", ""), ("action_url", ""), ("action_label", ""), ("last_action", "")]:
    if key not in st.session_state:
        st.session_state[key] = default

SYSTEM_PROMPT = """You are Rio (රියෝ), a friendly and capable AI assistant. Reply in the language used by the user (Sinhala or English). Be clear, accurate and concise. You can explain how to use a computer, but do not claim you have directly controlled the user's device. You cannot access files, launch desktop applications, change settings, or perform actions outside this web app unless an explicit supported feature does so. Ask for clarification when needed."""

# Safe arithmetic evaluator: supports only numbers and basic arithmetic operators.
def safe_calculate(expression):
    expression = expression.replace("×", "*").replace("÷", "/").replace("−", "-").strip()
    if not re.fullmatch(r"[0-9+*/().%\-\s]+", expression):
        raise ValueError("Only basic arithmetic is supported.")
    tree = ast.parse(expression, mode="eval")
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Constant, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow, ast.UAdd, ast.USub)
    if any(not isinstance(node, allowed) for node in ast.walk(tree)):
        raise ValueError("Unsupported calculation.")
    def evaluate(node):
        if isinstance(node, ast.Expression): return evaluate(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)): return node.value
        if isinstance(node, ast.UnaryOp):
            val = evaluate(node.operand)
            return val if isinstance(node.op, ast.UAdd) else -val
        if isinstance(node, ast.BinOp):
            a, b = evaluate(node.left), evaluate(node.right)
            ops = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
            if isinstance(node.op, ast.Pow) and abs(b) > 10: raise ValueError("Power too large.")
            return ops[type(node.op)](a, b)
        raise ValueError("Invalid expression.")
    result = evaluate(tree)
    if abs(result) > 1e100: raise ValueError("Result too large.")
    return result


def handle_device_command(text):
    """Return True if this is a built-in browser/helper command."""
    q = text.strip()
    low = q.lower()
    # Open common sites in a user-clickable link (browser security prevents silent desktop control).
    sites = {
        "google": ("Google", "https://www.google.com"),
        "youtube": ("YouTube", "https://www.youtube.com"),
        "gmail": ("Gmail", "https://mail.google.com"),
        "wikipedia": ("Wikipedia", "https://www.wikipedia.org"),
        "facebook": ("Facebook", "https://www.facebook.com"),
    }
    for name, (label, url) in sites.items():
        if re.search(rf"\b(open|launch|visit)\s+{name}\b", low) or f"{name} අරින්න" in q:
            st.success(f"{label} විවෘත කිරීමට පහත සබැඳිය ඔබන්න.")
            st.link_button(f"Open {label}", url, use_container_width=True)
            return True
    search_match = re.match(r"(?:search(?:\s+for)?|google)\s+(.+)", q, flags=re.I)
    sinhala_match = re.match(r"(?:සොයන්න|සර්ච් කරන්න)\s+(.+)", q)
    if search_match or sinhala_match:
        term = (search_match or sinhala_match).group(1).strip()
        if term:
            url = "https://www.google.com/search?q=" + quote_plus(term)
            st.success(f"'{term}' සඳහා සෙවුම් ප්‍රතිඵල")
            st.link_button("🔎 Google Search", url, use_container_width=True)
            return True
    calc_match = re.match(r"(?:calculate|ගණනය කරන්න)\s+(.+)", q, flags=re.I)
    if calc_match:
        try:
            result = safe_calculate(calc_match.group(1))
            st.success(f"ගණනයේ පිළිතුර: **{result}**")
        except Exception as exc:
            st.warning(f"ගණනය කළ නොහැක: {exc}")
        return True
    if any(x in low for x in ["what time is it", "tell me the time"]) or "දැන් වෙලාව" in q:
        st.info("දැන් වේලාව: " + datetime.now().astimezone().strftime("%I:%M %p"))
        return True
    if low in ["help", "commands", "what can you do"] or "මොනවද කරන්න පුළුවන්" in q:
        st.markdown("""**Rioට කියන්න පුළුවන් විධාන:**
        - `Hey Rio, open Google` – Google වෙබ් අඩවියට සබැඳියක්
        - `Hey Rio, open YouTube` – YouTube වෙත සබැඳියක්
        - `Hey Rio, search for weather in Sri Lanka` – Google සෙවීමක්
        - `Hey Rio, calculate 25 * 4` – මූලික ගණනයක්
        - `Hey Rio, what time is it?` – දේශීය වේලාව
        - වෙනත් ප්‍රශ්න සාමාන්‍යයෙන් අසන්න – Gemini AI පිළිතුරු දෙයි.
        """)
        return True
    return False


def ask_rio(user_text: str):
    user_text = user_text.strip()
    if not user_text:
        return
    if handle_device_command(user_text):
        st.session_state.messages.append({"role": "user", "content": user_text})
        return
    if not api_key:
        st.error("පළමුව වම් පැත්තේ Gemini API Key එක ඇතුළත් කරන්න.")
        return
    st.session_state.messages.append({"role": "user", "content": user_text})
    history = []
    for item in st.session_state.messages[-16:]:
        role = "user" if item["role"] == "user" else "model"
        history.append(types.Content(role=role, parts=[types.Part(text=item["content"])]))
    try:
        client = genai.Client(api_key=api_key)
        with st.spinner("Rio පිළිතුර සකස් කරමින්..."):
            response = client.models.generate_content(model=model, contents=history, config=types.GenerateContentConfig(system_instruction=SYSTEM_PROMPT, temperature=0.7))
        answer = response.text or "සමාවන්න, මේ අවස්ථාවේ පිළිතුරක් ලබාගත නොහැක."
        st.session_state.messages.append({"role": "assistant", "content": answer})
        st.markdown(answer)
        if voice_on:
            try:
                lang = "si" if re.search(r"[\u0D80-\u0DFF]", answer) else "en"
                with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as f:
                    audio_path = f.name
                gTTS(text=answer, lang=lang).save(audio_path)
                st.audio(audio_path, format="audio/mp3")
                Path(audio_path).unlink(missing_ok=True)
            except Exception:
                st.caption("හඬ ප්‍රතිදානය ලබාගත නොහැකි වුණා.")
    except Exception as exc:
        st.error(f"AI සේවාව සමඟ සම්බන්ධ වීමේ දෝෂයක්: {exc}")

# Wake word listener in browser.
voice_event = wake_component(enabled=st.session_state.wake_enabled, language="si-LK" if wake_language.startswith("සිංහල") else "en-US", key="rio_wake_component", default=None)
if isinstance(voice_event, dict) and voice_event.get("event_id") != st.session_state.last_wake_event:
    st.session_state.last_wake_event = voice_event.get("event_id")
    heard = (voice_event.get("text") or "").strip()
    if heard:
        st.session_state.pending_voice_text = heard
        st.rerun()

if st.session_state.pending_voice_text:
    pending = st.session_state.pending_voice_text
    st.session_state.pending_voice_text = ""
    st.success(f"Rioට ඇසුණේ: {pending}")
    ask_rio(pending)

st.markdown("### 🎙️ Hands-free Wake Word")
a, b = st.columns(2)
with a:
    if st.button("▶️ Hey Rio සවන් දීම ආරම්භ කරන්න", use_container_width=True):
        st.session_state.wake_enabled = True
        st.rerun()
with b:
    if st.button("⏹️ සවන් දීම නවත්වන්න", use_container_width=True):
        st.session_state.wake_enabled = False
        st.rerun()
if st.session_state.wake_enabled:
    st.info("මයික්‍රෆෝනය සක්‍රියයි. 'Hey Rio' කියා ඉන්පසු විධානය කියන්න. නවත්වන්න බොත්තම ඔබන තුරු සවන් දීමට උත්සාහ කරයි.")
else:
    st.caption("අවදි වචනය භාවිතයට ඉහත ආරම්භක බොත්තම ඔබන්න.")

st.markdown("### 🖥️ Rioට කළ හැකි පරිගණක/වෙබ් කාර්යයන්")
st.write("වෙබ් අඩවි විවෘත කිරීම සඳහා ආරක්ෂිත සබැඳි, Google සෙවීම, මූලික ගණනය සහ වේලාව පෙන්වීම. Browser ආරක්ෂක සීමා නිසා මේ web app එකෙන් පරිගණකයේ වෙනත් apps හෝ settings ස්වයංක්‍රීයව පාලනය කළ නොහැක.")
with st.expander("විධාන උදාහරණ බලන්න"):
    st.markdown("- `Hey Rio, open Google`\n- `Hey Rio, open YouTube`\n- `Hey Rio, search for engineering drawing`\n- `Hey Rio, calculate 125 / 5`\n- `Hey Rio, what time is it?`\n- `Hey Rio, help` / `රියෝ, මොනවද කරන්න පුළුවන්`")

st.markdown("### 💬 Rio සමඟ කතාබහ")
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
col1, col2 = st.columns([4, 1])
with col1:
    typed = st.chat_input("Rioට පණිවිඩයක් ලියන්න...")
with col2:
    if st.button("🗑️ Clear", use_container_width=True):
        st.session_state.messages = []
        st.rerun()
if typed:
    ask_rio(typed)
    st.rerun()

st.markdown("### 🎤 එක් වරක් හඬින් විධානයක් දෙන්න")
spoken_text = speech_to_text(language="si-LK", start_prompt="🎤 කතා කරන්න", stop_prompt="⏹️ නවත්වන්න", just_once=True, use_container_width=True, key="rio_speech_input")
if spoken_text:
    st.caption(f"හඳුනාගත් හඬ: {spoken_text}")
    ask_rio(spoken_text)
    st.rerun()

st.markdown('<div class="credit">Created by H.W.D.Sonal chamikara</div>', unsafe_allow_html=True)

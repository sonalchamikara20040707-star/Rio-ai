RIO AI ASSISTANT - VOICE + DESKTOP-HELPER UPDATE

FEATURES
- Gemini-powered Sinhala/English chat
- Text input and one-shot microphone input
- Browser wake word listener for "Hey Rio" / "Rio" (English) or "රියෝ" (browser Sinhala support varies)
- Spoken AI answers (gTTS)
- Built-in safe commands: open Google/YouTube/Gmail/Wikipedia, Google search, basic arithmetic, tell local time, show help
- Creator credit: Created by H.W.D.Sonal chamikara

INSTALL / RUN (Windows, macOS, Linux)
1. Extract this ZIP file.
2. Install Python 3.10 or newer.
3. Open Terminal / Command Prompt in the extracted folder.
4. Install dependencies:
   pip install -r requirements.txt
5. Start Rio:
   streamlit run app.py
6. Open the local URL shown in the terminal (usually http://localhost:8501).
7. Add your Gemini API key in the left sidebar. Get one from https://aistudio.google.com/apikey
8. Click "Hey Rio සවන් දීම ආරම්භ කරන්න" and allow microphone permission.
9. Say "Hey Rio, open YouTube" or say "Hey Rio" and then give a command.

VOICE COMMAND EXAMPLES
- Hey Rio, open Google
- Hey Rio, open YouTube
- Hey Rio, search for engineering drawing
- Hey Rio, calculate 125 / 5
- Hey Rio, what time is it?
- Hey Rio, help

IMPORTANT LIMITATIONS
- Wake-word recognition uses the browser Web Speech API. Current Chrome/Edge are recommended; keep the page open and microphone permission enabled. Internet may be required. Sinhala wake-word support depends on browser speech recognition support.
- A browser-based website cannot silently launch arbitrary desktop apps, change OS settings, control the whole computer, or access local files. For safety and browser security, Rio provides user-clickable website/search links and limited built-in commands instead.
- For real desktop app control, a separately installed native desktop app with explicit permissions would be required; this Streamlit web version does not do that.
- Keep your Gemini API key private. Do not publish it or commit it to a public repository.
